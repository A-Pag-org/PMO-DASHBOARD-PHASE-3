repo: A-Pag-org/PMO-DASHBOARD-PHASE-3
branch: main

## Last sync
date: 2026-08-13

### Updated in this project
- Repository associated as the source for the Delhi NCR Clean Air dashboards.
- Repository is currently empty on `main` (no tree to read yet), so nothing was imported.
- Dashboard screens in this project were authored here, not derived from repo files.

## Screen map
| Screen | Repo files |
|---|---|
| Delhi NCR Summary.dc.html | — (authored in project) |
| Delhi NCR Clean Air Dashboard.dc.html (PARIVARTAN, MRS) | — (authored in project) |
| Road Repair Dashboard.dc.html | — (authored in project) |
| SCC Dashboard.dc.html | — (authored in project) |
| Greening Dashboard.dc.html | — (authored in project) |
| ICCC Dashboard.dc.html | — (authored in project) |
| CEMS and APCD Dashboard.dc.html | — (authored in project) |
