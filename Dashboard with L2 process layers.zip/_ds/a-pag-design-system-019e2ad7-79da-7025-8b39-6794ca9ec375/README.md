# A-PAG — Design System

> **A-PAG** (Air Pollution Action Group), pronounced *æ-păg* — the hyphen makes you read **A**, then **PAG** (like "bag"). A non-profit philanthropic foundation (also registered as **FIQL — Foundation for Improving the Quality of Life**) founded in 2019, on a mission to **reduce air pollution in India**.

This repository is a living design system: brand foundations (color, type, spacing), real visual assets (logo lockups, documentary photography), a functional Air Quality Index colour scale, preview cards for the Design System tab, and a brand-faithful UI kit recreating A-PAG's web presence.

---

## 1. What A-PAG does

A-PAG's work is **singularly focused on air pollution** — unlike broader environmental NGOs. It works *with* government, at all levels (Centre, State, municipal), with a bias toward **making things happen on the ground**.

- **Mission:** reduce air pollution in Indian cities; improve air quality to meet basic sustenance levels.
- **Geography:** began in the **Indo-Gangetic Plain** (where severity is highest); expanding to **Andhra Pradesh, Odisha** and beyond.
- **Sector-agnostic** across the **5 sources of pollution**: dust, industrial, domestic, biomass, vehicular.
- **Model:** pilot in small geographies → learn → scale rapidly.

**Three-pronged approach**
1. **Program Implementation Support** — deploy Project Management Units (PMUs) at Centre/State/municipal levels for enforcement & implementation.
2. **Creation of Knowledge Resources** — toolkits, dashboards (e.g. sensitization toolkit, clean air project dashboard) for governments, intermediaries & CSOs.
3. **Policy Research & Advocacy** — support executive/legislative decision-making so air pollution gets the focus it merits.

**Signature campaign:** `#pollutionkakyaplanhai` (Aug 2019) — making air pollution a poll issue to drive political will.

**Why it matters (the stats they lead with):** Air pollution is the **4th** leading global risk factor for death; India is the **2nd-most-polluted** country; living in Delhi shortens lifespan by **~10 years**; dispersed sources (malba, garbage dumps, construction waste) drive ~**45%** of Delhi's PM2.5 load.

**Contact:** 242, Okhla Industrial Estate, Phase 3, New Delhi – 110020 · [a-pag.org](https://a-pag.org) · [@APAGIndia](https://x.com/apagindia) · [LinkedIn](https://in.linkedin.com/company/apag)

### Sources used to build this system
- **Uploaded:** `uploads/A-PAG - Air Pollution Action Group.pdf` — a content scrape of the website (copy + 7 documentary photographs, extracted into `assets/images/`).
- **Uploaded:** the **official logo artwork** (`APAG tagline final 2020.jpg`) — the authoritative source for the wordmark, the yellow box around the “A”, the charcoal grey, and the typeface (**Myriad**). Trimmed + processed into `assets/logo/`.
- **Live site:** [a-pag.org](https://a-pag.org) — *note:* the current live site runs on a generic "Greenergy" WordPress theme with placeholder team names/imagery, so it is **not** a reliable source of the true brand. Treated as content reference only.
- **Brand identity case study:** [Design Dimensions on Behance](https://www.behance.net/gallery/95981517/A-PAG-Air-Pollution-Action-Group) — the source for brand *intent* (yellow rationale, "bold/vibrant/minimal", yellow-band & BREATHE motifs, hyphenated wordmark).

> ⚠️ The colours and logo here are taken from the **official artwork**. The only substitution is the **typeface**: Myriad is a licensed Adobe font, so **Source Sans 3** (Adobe's open, humanist sibling of Myriad) stands in. See **Caveats**.

---

## 2. Content fundamentals — how A-PAG writes

**Voice:** Urgent but constructive. Serious about the problem, optimistic about the fix — the same duality as the yellow (alarm + hope). Plain, direct, evidence-led. Never preachy or doom-only; always points to *action* and *what works*.

**Person:** Mostly **"we" / "our"** for A-PAG ("Our approach…", "We deploy…", "We produce…"). Addresses the reader as **"you"** in calls to action ("We need your voice, join us").

**Casing:** Sentence case for body and most headlines. **UPPERCASE** reserved for poster moments (BREATHE), eyebrows/labels, and the wordmark. Title Case for proper program names (Project Management Units, Knowledge Resources).

**Spelling:** British/Indian English — *organisation, programme/program, sensitization* appear; "civil society organisations (CSOs)". Keep Indian conventions.

**Numbers & stats:** Used as punches, sparingly and specifically: "4th", "second-most polluted", "10 years", "15%+", "45%". Always concrete, always sourced to a study/place. Numerals (not spelled out) for impact.

**Sentence shape:** Short, declarative. One idea per sentence. Crisp and "direct, to ensure readers get the information they are looking for" (their own brief). Avoid hedging and jargon; explain acronyms on first use (PMU, CSO).

**Emoji:** Not used in prose. The one playful device is the **hashtag campaign** `#pollutionkakyaplanhai` (Hindi: "what's the plan for pollution?") — Hinglish is welcome for campaigns.

**Examples (verbatim tone):**
- "Air pollution is a serious issue. A-PAG is here to solve it."
- "We are sector-agnostic and work across all 5 sources of pollution."
- "We need your voice, join us!"
- One-word imperatives as motifs: **"BREATHE."**, **"Now."**

---

## 3. Visual foundations

The brand brief in three words: **bold · vibrant · minimal.**

### Colour
- **Signal Yellow `#F7EB22`** (bright lemon, sampled from the logo) is *the* brand colour — the box around the “A”, the band, the highlight. Chosen to **grab attention** ("air pollution is an issue — not tomorrow, now") while carrying a subliminal message of **hope/optimism**. Use it as an accent, never a wash.
- **Ink `#383A3C`** (cool charcoal — the logo grey, *not* pure black) carries the seriousness; primary text. **Ink deep `#232527`** for full-bleed dark sections.
- **Paper `#F6F6F4`** (cool near-white) is the default ground; pure white for cards.
- A **cool/neutral grey scale** (50–900, anchored on the logo charcoal) for text tiers, borders, surfaces.
- A separate **functional AQI scale** (India CPCB: Good→Severe) used *only* for air-quality data — never decoratively, and kept distinct from brand yellow.
- **Imagery is warm-cast:** dawn/dusk sodium light, smog haze, amber/grey tones.

### Type
- **Myriad** is the official A-PAG typeface (the logo is set in a wide/"full-stretch" Myriad). It's a licensed Adobe humanist sans — friendly but serious.
- **Source Sans 3** (Adobe's open sibling of Myriad) is the substitute used across this system — heavy weights (800/900) with tight tracking for display & poster moments; 400–600 for crisp, direct body/UI copy.
- **Source Code Pro** (same Adobe superfamily) for AQI readings, PM figures and all metrics — a quiet "monitoring/scientific" register.
- *(Swap in licensed Myriad when available; see Caveats.)*

### Layout & structure
- **Full-bleed bands** are the organising device: a documentary photo band, then a yellow band, then an ink band, then paper. Sections stack edge-to-edge; the **yellow band "stands proud"** as the recurring punctuation.
- Generous margins, lots of breathing room (literal and figurative). Minimal ornament.
- Strong left-aligned hierarchy; uppercase **eyebrows** with wide tracking introduce sections.
- Grid-based, but happy to break to a single bold statement on a photo.

### Corners, borders, shadows
- **Crisp by default.** Bands and full-bleed blocks are radius `0`. Cards use a small radius (`4–8px`). Pills only for chips/tags.
- Borders are **hairlines** in warm grey (`--line-1/2`); on ink, a faint white line.
- **Shadows are restrained** — the aesthetic is largely flat. Use `sh-1/2` for lift; the one expressive shadow is a **yellow glow** under primary CTAs.

### Motion & states
- **Subtle, purposeful.** Short fades/translations (~120–220ms), `cubic-bezier(.2,.7,.2,1)`. No bounces, no decorative parallax beyond a gentle hero.
- **Hover:** primary yellow → deeper amber (`--apag-yellow-deep`); ink → slightly lifted ink; ghost → fills ink. Links carry a thick **yellow underline** that the brand "owns".
- **Press:** a 1px downward nudge (`translateY(1px)`); no scaling.
- **Focus:** 3px soft-yellow ring (`--apag-yellow-soft`) + ink border — visible and accessible.

### Transparency / blur
- Used sparingly: **protection gradients** (ink → transparent) over photos so white/yellow text stays legible. Avoid frosted-glass/blur panels — they read too "techy" for this serious, documentary brand.

### Signature devices
- The **yellow box around the “A”** in the wordmark — the core identity gesture.
- The **yellow band** (proud horizontal block, often with a single word or stat) — an echo of the box at layout scale.
- The word **"BREATHE"** as a recurring quiet imperative (it lived on the envelope flaps in the original stationery).
- The **square-dot separator** in the mark (`A·PAG`).
- The yellow **inline text highlight** (`.mark`) on a key phrase.

---

## 4. Iconography

See **`ICONOGRAPHY.md`** for the full approach. In short:
- No proprietary icon font or custom icon set was found in the source material. A-PAG's own visual language leans on **photography + bold type**, not iconography.
- This system standardises on **[Lucide](https://lucide.dev)** (clean, consistent 1.75–2px stroke, rounded joins) loaded from CDN — it matches the minimal, modern, no-nonsense tone. *(Substitution — flagged.)*
- Icons are used **functionally and sparingly** (arrows, wind/air, factory, dust, leaf, map-pin), always inheriting `currentColor`. No multicolour or emoji icons in UI. Inline arrow glyphs appear on CTAs.

---

## 5. Index — what's in this repo

| Path | What it is |
|---|---|
| `README.md` | This file — brand context, content & visual foundations, index. |
| `ICONOGRAPHY.md` | Icon approach, library, usage rules. |
| `colors_and_type.css` | **Source of truth** for all CSS variables: colour, type, spacing, radii, shadows, motion + semantic `.apag` element defaults. |
| `assets/logo/` | Logo artwork — `apag-logo.png` / `.jpg` (primary, on light), `apag-logo-reversed.png` (on charcoal). Derived from official uploaded artwork. |
| `assets/images/` | 7 documentary photographs (smog, traffic, biomass burning, hazy cityscapes) extracted from the source PDF. |
| `preview/` | Design-system preview cards (registered in the Design System tab) — colour, type, spacing, components, brand. |
| `ui_kits/website/` | Brand-faithful recreation of A-PAG's marketing site — `index.html` + JSX components. |
| `SKILL.md` | Agent-Skill manifest so this system can be used in Claude Code. |

### Quick start
1. Link the tokens: `<link rel="stylesheet" href="colors_and_type.css">`.
2. Wrap content in `<body class="apag">` to inherit semantic type/colour defaults.
3. Use CSS vars (`var(--apag-yellow)`, `var(--font-display)`, `var(--s-5)` …) everywhere — don't hard-code values.
4. For air-quality data, use the `--aqi-*` scale only.

---

## 6. Caveats & open questions (help us make this perfect)

- **Typeface is the one substitution.** Myriad (the official face) is a licensed Adobe font, so **Source Sans 3** stands in. If you have the licensed **Myriad** web fonts, drop them in `fonts/` and update `--font-sans`/`--font-display` — everything else will reflow correctly.
- **Logo & colour are from official artwork** (the uploaded `APAG tagline final 2020.jpg`): yellow `#F7EB22`, charcoal `#383A3C`. If you have **vector (SVG/EPS/AI)** logo files, share them — the current `assets/logo/` files are a high-res raster trim + a recoloured reversed version.
- The **live a-pag.org** is a placeholder template; the UI kit is rebuilt in the *true* brand language rather than copied from it.
- **Lucide** stands in for iconography — confirm or replace.
- AQI colours follow the **India CPCB** national standard; confirm if A-PAG uses a customised scale.
