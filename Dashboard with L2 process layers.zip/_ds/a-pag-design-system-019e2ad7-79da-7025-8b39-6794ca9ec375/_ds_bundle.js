/* @ds-bundle: {"format":3,"namespace":"APAGDesignSystem_019e2a","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.APAGDesignSystem_019e2a = window.APAGDesignSystem_019e2a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
